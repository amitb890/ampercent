<?php 
$homeUrl = 'http://www.ampercent.com/'; 
header("HTTP/1.0 404 Not Found"); 
$arPath = explode('/', $_SERVER['REQUEST_URI']); 
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"> 
<head> 
<title>404 Error - Page not found</title> 
<meta http-equiv="refresh" content="25;url=<?php echo $homeUrl;?>" /> <!-- the page will be reloaded in 25secs change the value to change the time-->
<style type="text/css"> 
*{margin:0px;padding:0px;} 
body{background-color:#F9F9F9;color:#111;font: normal 95%/130% "Trebuchet MS", Verdana, Arial, sans-serif;margin:20px 80px;padding:20px 0px;} 
a {color:#6699CC;text-decoration:none;border-bottom: 1px solid #EEE;} 
h1{color:#000;font:normal 17px Georgia, "Times New Roman", Times, serif;margin:0px;padding:0px;} 
h2,h3{color: #6699cc;font: normal 1.25em Georgia, "Times New Roman", Times, serif;margin: 20px 0px;padding: 0px;} 
ul{margin:10px 20px;} 
li{list-style:disc;} 
#wrapper{background-color:#FFFFFF;border:1px solid #DDDDDD;margin:auto;width:80%;} 
#header {background:#004A95;border-bottom:1px solid #DDD;color:#888;font-size:85%;margin:0px;padding:3px 10px;width:100%;} 
#body{padding:15px 80px;} 
#goog-wm { } 
#goog-wm h3.closest-match { } 
#goog-wm h3.closest-match a { } 
#goog-wm h3.other-things { } 
#goog-wm ul li { } 
#goog-wm li.search-goog {} 
.comment{color:#999;} 
</style> 
</head> 
<body> 
<div id="wrapper"> 
<div id="header" style="width: 836px; height: 26px"> 
<a style="text-transform:uppercase;" href="<?php echo $homeUrl;?>">
<p align="center"><?php echo str_replace(array('http://', 'www.', '/'), '', $homeUrl);?></a> &#8594; 
<font color="#AAC6FF">Sorry the page/file you are looking for isn't here</font></div> 
<div id="body"> 

	<table border="0" width="100%" cellspacing="1">

		<tr>
			<td colspan="7" bgcolor="#FFFFFF">
<p align="center"><b>It was because the page/file was not found on this server.</b></p>
<p align="center">&nbsp;</p>
<p align="center">Please ensure that you have entered the url correctly. If you did so, then probably the 
page/file was removed from the server.</p>
<p align="center">&nbsp;</p>
<p align="center"><font color="#000080"><b>Please choose one of the actions from below, or you will be redirected to our homepage in 
25 seconds.</b></font></p>
			<p align="center">&nbsp;</p> 
			</td>
		</tr>
		<tr>
			<td colspan="7" bgcolor="#FFFFFF">&nbsp;</td>
		</tr>
		<tr>
			<td width="1%" height="29" bgcolor="#FFFFFF">&nbsp;</td>
			<td width="26%" height="29" bgcolor="#000066" bordercolorlight="#000000" bordercolordark="#000000">
			<p align="center"><a href="<?php echo $homeUrl;?>"><b>Go to Homepage</b> &raquo;</a></td>
			<td width="1%" height="29" bgcolor="#FFFFFF">&nbsp;</td>
			<td width="48%" height="29" bgcolor="#000000" bordercolorlight="#000000" bordercolordark="#000000">
			<p align="center"><a href="javascript:history.back();"><b>Go back to Where you came from</b> &raquo;</a></td>
			<td width="1%" height="29" bgcolor="#FFFFFF">&nbsp;</td>
			<td width="20%" height="29" bgcolor="#000066" bordercolorlight="#000000" bordercolordark="#000000">
			<p align="center"><a href="your-contact-page-url-goes-here"><b>Contact Us</b> &raquo;</td>
			<td width="1%" height="29" bgcolor="#FFFFFF">&nbsp;</td>
		</tr>
		<tr>
			<td colspan="7" bgcolor="#FFFFFF">&nbsp;</td>
		</tr>
		<tr>
			<td colspan="7" bgcolor="#555555">
			<p align="center">	<div id="leftContent"> 
<script type="text/javascript"> 
  var GOOG_FIXURL_LANG = 'en'; 
  var GOOG_FIXURL_SITE = '<?php echo $homeUrl;?>'; 
</script> 
<script type="text/javascript" 
    src="http://linkhelp.clients.google.com/tbproxy/lh/wm/fixurl.js"></script> 
</div></td>
		</tr>
		<tr>
			<td colspan="7" bgcolor="#FFFFFF">&nbsp;</td>
		</tr>
		<tr>
			<td colspan="7" bgcolor="#FFFFFF">
			<p align="center"><font size="2">Page designed by 
			<a href="http://www.ampercent.com/">Soumen Halder</a></font></td>
		</tr>
	</table>



	<div id="leftContent"> 
<script type="text/javascript"> 
  var GOOG_FIXURL_LANG = 'en'; 
  var GOOG_FIXURL_SITE = '<?php echo $homeUrl;?>'; 
</script> 
<script type="text/javascript" 
    src="http://linkhelp.clients.google.com/tbproxy/lh/wm/fixurl.js"></script> 
</div> 
</div> 
</div> 
</body> 
</html>